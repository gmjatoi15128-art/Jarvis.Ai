import { useCallback, useMemo, useState } from "react";
import {
  Brain, Calculator, ChevronRight, Clock3, Globe, Home, Mic, MicOff,
  Settings as SettingsIcon, Shield, Sparkles, Trash2, Volume2, VolumeX, Wrench, X
} from "lucide-react";
import { Message, Memory, Settings } from "./types";
import { defaultSettings, loadMemories, loadMessages, loadSettings, saveMemories, saveMessages, saveSettings } from "./lib/storage";
import { getAssistantReply, speak } from "./lib/assistant";
import { useSpeechRecognition } from "./hooks/useSpeechRecognition";

type Tab = "home" | "chat" | "memory" | "tools" | "settings";

function uid() {
  return crypto.randomUUID();
}

export default function App() {
  const [tab, setTab] = useState<Tab>("home");
  const [messages, setMessages] = useState<Message[]>(loadMessages());
  const [memories, setMemories] = useState<Memory[]>(loadMemories());
  const [settings, setSettings] = useState<Settings>(loadSettings());
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);

  const updateSettings = (patch: Partial<Settings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    saveSettings(next);
  };

  const addMessage = (message: Message) => {
    setMessages(prev => {
      const next = [...prev, message];
      saveMessages(next);
      return next;
    });
  };

  const handleText = useCallback(async (text: string) => {
    const cleaned = text.trim();
    if (!cleaned || thinking) return;
    setInput("");
    const userMessage: Message = { id: uid(), role: "user", content: cleaned, createdAt: Date.now() };
    addMessage(userMessage);
    setThinking(true);
    const reply = await getAssistantReply(cleaned, settings, memories, [...messages, userMessage]);
    const assistantMessage: Message = { id: uid(), role: "assistant", content: reply, createdAt: Date.now() };
    addMessage(assistantMessage);
    setThinking(false);
    if (settings.voiceEnabled) speak(reply);
  }, [thinking, settings, memories, messages]);

  const { supported, listening, start, stop } = useSpeechRecognition(handleText);

  const quickActions = useMemo(() => [
    { label: "What time is it?", icon: Clock3 },
    { label: "Calculate 25 * 18", icon: Calculator },
    { label: "Who are you?", icon: Sparkles },
  ], []);

  function clearChat() {
    setMessages([]);
    saveMessages([]);
  }

  function addMemory() {
    const text = window.prompt("What should JARVIS remember?");
    if (!text?.trim()) return;
    const next = [...memories, { id: uid(), text: text.trim(), createdAt: Date.now() }];
    setMemories(next);
    saveMemories(next);
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-orb"><Sparkles size={18} /></div>
          <div>
            <div className="brand-name">JARVIS</div>
            <div className="brand-status">{thinking ? "Thinking" : listening ? "Listening" : "Online"}</div>
          </div>
        </div>
        <button className="icon-button" onClick={() => setTab("settings")} aria-label="Settings">
          <SettingsIcon size={20} />
        </button>
      </header>

      <main className="content">
        {tab === "home" && (
          <HomeScreen
            listening={listening}
            thinking={thinking}
            supported={supported}
            start={start}
            stop={stop}
            onText={handleText}
            quickActions={quickActions}
            goChat={() => setTab("chat")}
            userName={settings.userName}
          />
        )}

        {tab === "chat" && (
          <ChatScreen
            messages={messages}
            input={input}
            setInput={setInput}
            send={() => handleText(input)}
            clearChat={clearChat}
            thinking={thinking}
          />
        )}

        {tab === "memory" && (
          <MemoryScreen memories={memories} addMemory={addMemory} removeMemory={(id) => {
            const next = memories.filter(m => m.id !== id);
            setMemories(next);
            saveMemories(next);
          }} />
        )}

        {tab === "tools" && <ToolsScreen />}

        {tab === "settings" && (
          <SettingsScreen
            settings={settings}
            updateSettings={updateSettings}
            reset={() => {
              setSettings(defaultSettings);
              saveSettings(defaultSettings);
            }}
          />
        )}
      </main>

      <nav className="bottom-nav">
        <NavButton active={tab === "home"} label="Home" icon={Home} onClick={() => setTab("home")} />
        <NavButton active={tab === "chat"} label="Chat" icon={Sparkles} onClick={() => setTab("chat")} />
        <NavButton active={tab === "memory"} label="Memory" icon={Brain} onClick={() => setTab("memory")} />
        <NavButton active={tab === "tools"} label="Tools" icon={Wrench} onClick={() => setTab("tools")} />
      </nav>
    </div>
  );
}

function NavButton({ active, label, icon: Icon, onClick }: { active: boolean; label: string; icon: any; onClick: () => void }) {
  return <button className={`nav-button ${active ? "active" : ""}`} onClick={onClick}><Icon size={20} /><span>{label}</span></button>;
}

function HomeScreen(props: any) {
  return (
    <section className="screen home-screen">
      <div className={`ai-core ${props.listening ? "is-listening" : ""} ${props.thinking ? "is-thinking" : ""}`}>
        <div className="core-ring ring-one" />
        <div className="core-ring ring-two" />
        <div className="core-center"><Brain size={44} /></div>
      </div>

      <div className="hero-copy">
        <div className="eyebrow">PERSONAL AI</div>
        <h1>{props.thinking ? "Processing…" : props.listening ? "I'm listening." : `Good to see you, ${props.userName}.`}</h1>
        <p>{props.thinking ? "Working through your request." : "Your personal assistant, ready when you are."}</p>
      </div>

      <div className="voice-row">
        <button className={`voice-button ${props.listening ? "active" : ""}`} onClick={props.listening ? props.stop : props.start}>
          {props.listening ? <MicOff size={28} /> : <Mic size={28} />}
        </button>
        <div className="voice-caption">{props.supported ? "Tap to speak" : "Voice input isn't supported in this browser"}</div>
      </div>

      <div className="quick-grid">
        {props.quickActions.map((action: any) => {
          const Icon = action.icon;
          return <button key={action.label} className="quick-card" onClick={() => props.onText(action.label)}>
            <Icon size={18} /><span>{action.label}</span><ChevronRight size={16} />
          </button>
        })}
      </div>

      <button className="secondary-cta" onClick={props.goChat}><Sparkles size={17}/> Open conversation</button>
    </section>
  );
}

function ChatScreen({ messages, input, setInput, send, clearChat, thinking }: any) {
  return (
    <section className="screen chat-screen">
      <div className="screen-title">
        <div><div className="eyebrow">CONVERSATION</div><h2>Talk to JARVIS</h2></div>
        <button className="danger-icon" onClick={clearChat} aria-label="Clear conversation"><Trash2 size={18}/></button>
      </div>
      <div className="chat-list">
        {messages.length === 0 && <div className="empty-state"><Sparkles size={30}/><p>Your conversation will appear here.</p></div>}
        {messages.map((m: Message) => <div key={m.id} className={`bubble ${m.role}`}><div className="bubble-label">{m.role === "assistant" ? "JARVIS" : "YOU"}</div><div>{m.content}</div></div>)}
        {thinking && <div className="bubble assistant"><div className="bubble-label">JARVIS</div><div className="typing">•••</div></div>}
      </div>
      <form className="composer" onSubmit={(e) => { e.preventDefault(); send(); }}>
        <input value={input} onChange={e => setInput(e.target.value)} placeholder="Talk to JARVIS…" />
        <button className="send-button" disabled={!input.trim() || thinking}><ChevronRight size={20}/></button>
      </form>
    </section>
  );
}

function MemoryScreen({ memories, addMemory, removeMemory }: any) {
  return <section className="screen">
    <div className="screen-title"><div><div className="eyebrow">MEMORY</div><h2>What I remember</h2></div><button className="primary-small" onClick={addMemory}>+ Add</button></div>
    <div className="card-stack">
      {memories.length === 0 && <div className="empty-state"><Brain size={30}/><p>No memories yet. Add something important and JARVIS will keep it locally on this device.</p></div>}
      {memories.map((m: Memory) => <div className="memory-card" key={m.id}><Brain size={18}/><span>{m.text}</span><button className="ghost-icon" onClick={() => removeMemory(m.id)}><Trash2 size={16}/></button></div>)}
    </div>
  </section>;
}

function ToolsScreen() {
  const tools = [
    ["Web Search", Globe, "Connect a search provider later."],
    ["Calculator", Calculator, "Basic arithmetic is built in."],
    ["Privacy", Shield, "Your local memories stay in browser storage."],
  ] as const;
  return <section className="screen">
    <div className="screen-title"><div><div className="eyebrow">CAPABILITIES</div><h2>Tools</h2></div></div>
    <div className="card-stack">
      {tools.map(([title, Icon, desc]) => <div className="tool-card" key={title}><div className="tool-icon"><Icon size={18}/></div><div><strong>{title}</strong><p>{desc}</p></div><ChevronRight size={18}/></div>)}
    </div>
  </section>;
}

function SettingsScreen({ settings, updateSettings, reset }: any) {
  return <section className="screen">
    <div className="screen-title"><div><div className="eyebrow">SYSTEM</div><h2>Settings</h2></div></div>
    <div className="settings-card">
      <label>Assistant name<input value={settings.assistantName} onChange={e => updateSettings({assistantName:e.target.value})}/></label>
      <label>Your name<input value={settings.userName} onChange={e => updateSettings({userName:e.target.value})}/></label>
      <label>Personality<textarea value={settings.personality} onChange={e => updateSettings({personality:e.target.value})}/></label>
      <div className="setting-row"><span><Volume2 size={18}/>Voice responses</span><input type="checkbox" checked={settings.voiceEnabled} onChange={e => updateSettings({voiceEnabled:e.target.checked})}/></div>
      <div className="divider" />
      <div className="section-label">FREE LOCAL AI (OPTIONAL)</div>
      <p className="muted">Enable this when you have a local Ollama server available. JARVIS will send conversation context to it instead of using the built-in demo brain.</p>
      <div className="setting-row"><span><Brain size={18}/>Use local AI</span><input type="checkbox" checked={settings.ollamaEnabled} onChange={e => updateSettings({ollamaEnabled:e.target.checked})}/></div>
      <label>Ollama URL<input value={settings.ollamaUrl} onChange={e => updateSettings({ollamaUrl:e.target.value})}/></label>
      <label>Model<input value={settings.ollamaModel} onChange={e => updateSettings({ollamaModel:e.target.value})}/></label>
      <button className="reset-button" onClick={reset}>Reset settings</button>
    </div>
  </section>;
}